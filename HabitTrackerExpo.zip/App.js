import React, { useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Platform,
} from 'react-native';
import Svg, { Defs, LinearGradient as SvgLinearGradient, Stop, ClipPath, Path, Rect, Ellipse, Circle, G, Text as SvgText } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  Easing,
  useAnimatedProps,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';

const AnimatedPath = Animated.createAnimatedComponent(Path);
const AnimatedCircle = Animated.createAnimatedComponent(Circle);

const jarsTop = [
  {
    id: 'water',
    name: 'Drink Water',
    goal: '8 glasses/day',
    emoji: '💧',
    fillLevel: 0.78,
    bubbles: true,
    lidTop: '#93c5fd',
    lidMid: '#3b82f6',
    lidBot: '#1d4ed8',
    glassLeft: '#bfdbfe',
    glassCenter: '#eff6ff',
    glassRight: '#60a5fa',
    waterTop: '#7dd3fc',
    badgeBg: '#dbeafe',
    badgeText: '#1e3a8a',
    badgeLabel: 'Health',
  },
  {
    id: 'workout',
    name: 'Workout',
    goal: '4 times/week',
    emoji: '🏋️',
    fillLevel: 0.55,
    bubbles: false,
    lidTop: '#86efac',
    lidMid: '#16a34a',
    lidBot: '#14532d',
    glassLeft: '#bbf7d0',
    glassCenter: '#f0fdf4',
    glassRight: '#4ade80',
    waterTop: '#4ade80',
    badgeBg: '#dcfce7',
    badgeText: '#14532d',
    badgeLabel: 'Fitness',
  },
  {
    id: 'meditate',
    name: 'Meditate',
    goal: '10 mins/day',
    emoji: '🧘',
    fillLevel: 0.45,
    bubbles: false,
    lidTop: '#f9a8d4',
    lidMid: '#db2777',
    lidBot: '#831843',
    glassLeft: '#fbcfe8',
    glassCenter: '#fdf2f8',
    glassRight: '#f472b6',
    waterTop: '#f9a8d4',
    badgeBg: '#fce7f3',
    badgeText: '#831843',
    badgeLabel: 'Mind',
  },
];

const jarsBottom = [
  {
    id: 'read',
    name: 'Read',
    goal: '20 mins/day',
    emoji: '📖',
    fillLevel: 0.5,
    bubbles: false,
    lidTop: '#fdba74',
    lidMid: '#ea580c',
    lidBot: '#7c2d12',
    glassLeft: '#fed7aa',
    glassCenter: '#fff7ed',
    glassRight: '#fb923c',
    waterTop: '#fdba74',
    badgeBg: '#ffedd5',
    badgeText: '#7c2d12',
    badgeLabel: 'Learning',
  },
  {
    id: 'alcohol',
    name: 'No Alcohol',
    goal: 'Stay clean',
    emoji: '🚫',
    fillLevel: 0.65,
    bubbles: true,
    lidTop: '#c4b5fd',
    lidMid: '#7c3aed',
    lidBot: '#3b0764',
    glassLeft: '#ddd6fe',
    glassCenter: '#f5f3ff',
    glassRight: '#a78bfa',
    waterTop: '#c4b5fd',
    badgeBg: '#ede9fe',
    badgeText: '#3b0764',
    badgeLabel: 'Lifestyle',
  },
];

function wavePath(level, phase, x = 13, width = 68) {
  const top = 30 + (1 - level) * 82;
  const amp = 5;
  const seg = width / 4;
  let d = `M${x},${top}`;
  for (let i = 0; i < 4; i += 1) {
    const x1 = x + i * seg + seg / 3;
    const x2 = x + i * seg + (2 * seg) / 3;
    const xe = x + (i + 1) * seg;
    const y1 = top + amp * Math.sin((phase + i + 0.2) * Math.PI);
    const y2 = top + amp * Math.sin((phase + i + 0.7) * Math.PI);
    const ye = top + amp * Math.sin((phase + i + 1.0) * Math.PI);
    d += ` C${x1},${y1} ${x2},${y2} ${xe},${ye}`;
  }
  d += ` L${x + width},${top + 22} L${x},${top + 22} Z`;
  return d;
}

function Jar({ jar }) {
  const drift = useSharedValue(0);
  const bubble1 = useSharedValue(0);
  const bubble2 = useSharedValue(0);

  useEffect(() => {
    drift.value = withRepeat(
      withTiming(1, { duration: 3200, easing: Easing.inOut(Easing.sin) }),
      -1,
      true
    );
    bubble1.value = withRepeat(withTiming(1, { duration: 2800, easing: Easing.linear }), -1, false);
    bubble2.value = withRepeat(withTiming(1, { duration: 3600, easing: Easing.linear }), -1, false);
  }, [bubble1, bubble2, drift]);

  const fillTop = 30 + (1 - jar.fillLevel) * 82;

  const wave1Props = useAnimatedProps(() => ({
    d: wavePath(jar.fillLevel, drift.value * 2),
  }));

  const wave2Props = useAnimatedProps(() => ({
    d: wavePath(jar.fillLevel, drift.value * 2 + 0.7),
  }));

  const bubble1Props = useAnimatedProps(() => ({
    cy: 100 - bubble1.value * 45,
    cx: 28 + Math.sin(bubble1.value * Math.PI * 2) * 2,
    opacity: 0.32 - bubble1.value * 0.32,
  }));

  const bubble2Props = useAnimatedProps(() => ({
    cy: 92 - bubble2.value * 38,
    cx: 62 + Math.sin(bubble2.value * Math.PI * 2) * 1.5,
    opacity: 0.22 - bubble2.value * 0.22,
  }));

  return (
    <View style={styles.jarWrap}>
      <Svg width={94} height={122} viewBox="0 0 94 122">
        <Defs>
          <SvgLinearGradient id={`lid_${jar.id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%" stopColor={jar.lidTop} />
            <Stop offset="45%" stopColor={jar.lidMid} />
            <Stop offset="100%" stopColor={jar.lidBot} />
          </SvgLinearGradient>
          <SvgLinearGradient id={`glass_${jar.id}`} x1="0" y1="0" x2="1" y2="0">
            <Stop offset="0%" stopColor={jar.glassLeft} stopOpacity="0.75" />
            <Stop offset="12%" stopColor={jar.glassCenter} stopOpacity="0.92" />
            <Stop offset="55%" stopColor={jar.glassCenter} stopOpacity="0.82" />
            <Stop offset="88%" stopColor={jar.glassRight} stopOpacity="0.7" />
            <Stop offset="100%" stopColor={jar.glassRight} stopOpacity="0.55" />
          </SvgLinearGradient>
          <SvgLinearGradient id={`water_${jar.id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%" stopColor={jar.waterTop} />
            <Stop offset="35%" stopColor={jar.lidMid} />
            <Stop offset="100%" stopColor={jar.lidBot} />
          </SvgLinearGradient>
          <ClipPath id={`clip_${jar.id}`}>
            <Path d="M13 30 L13 96 Q13 110 47 110 Q81 110 81 96 L81 30 Z" />
          </ClipPath>
        </Defs>

        <Ellipse cx="47" cy="24" rx="30" ry="5" fill={jar.lidBot} opacity="0.14" />
        <Rect x="17" y="6" width="60" height="20" rx="10" fill={`url(#lid_${jar.id})`} />
        <Rect x="22" y="8" width="50" height="7" rx="4" fill="white" opacity="0.28" />
        <Rect x="11" y="22" width="72" height="8" rx="4" fill={jar.lidBot} opacity="0.26" />
        <Rect x="11" y="22" width="72" height="3" rx="2" fill="white" opacity="0.12" />

        <Path
          d="M13 30 L13 96 Q13 112 47 112 Q81 112 81 96 L81 30 Z"
          fill={`url(#glass_${jar.id})`}
          stroke={jar.glassRight}
          strokeWidth="1.4"
        />

        <G clipPath={`url(#clip_${jar.id})`}>
          <Rect x="13" y={fillTop} width="68" height={112 - fillTop} fill={`url(#water_${jar.id})`} />
          <AnimatedPath animatedProps={wave1Props} fill={jar.lidMid} opacity="0.9" />
          <AnimatedPath animatedProps={wave2Props} fill="white" opacity="0.15" />
          {jar.bubbles ? (
            <>
              <AnimatedCircle animatedProps={bubble1Props} r="2.2" fill="white" />
              <AnimatedCircle animatedProps={bubble2Props} r="1.5" fill="white" />
            </>
          ) : null}
        </G>

        <Path d="M20 32 Q16 52 16 76 Q16 92 18 104" stroke="white" strokeWidth="6" strokeLinecap="round" opacity="0.42" />
        <Path d="M26 30 Q23 44 23 62" stroke="white" strokeWidth="2.5" strokeLinecap="round" opacity="0.22" />
        <Path d="M76 32 Q79 54 79 78 Q79 94 77 104" stroke={jar.glassRight} strokeWidth="3.5" strokeLinecap="round" opacity="0.45" />
        <Path d="M13 96 Q13 112 47 112 Q81 112 81 96 L81 104 Q81 114 47 114 Q13 114 13 104 Z" fill={jar.glassLeft} opacity="0.18" />
        <SvgText x="47" y={fillTop - 10} textAnchor="middle" fontSize="24">{jar.emoji}</SvgText>
        <Rect x="19" y="96" width="56" height="13" rx="6.5" fill={jar.lidBot} opacity="0.12" />
        <Rect x="20" y="97" width="54" height="11" rx="5.5" fill={jar.badgeBg} />
        <SvgText x="47" y="105.5" textAnchor="middle" fontSize="7" fontWeight="800" fill={jar.badgeText} letterSpacing="0.4">
          {jar.badgeLabel}
        </SvgText>
      </Svg>
      <Text style={styles.jarName}>{jar.name}</Text>
      <Text style={styles.jarGoal}>{jar.goal}</Text>
    </View>
  );
}

function Shelf({ items, two = false }) {
  return (
    <View style={styles.shelfUnit}>
      <View style={[styles.jarsRow, two && styles.jarsRow2]}>
        {items.map((jar) => <Jar key={jar.id} jar={jar} />)}
      </View>
      <LinearGradient
        colors={['#d4a96a', '#c49556', '#b8874a', '#a87840']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.shelfBoard}
      >
        <View style={styles.shelfFrontEdge} />
      </LinearGradient>
    </View>
  );
}

export default function App() {
  const week = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const done = [1, 1, 1, 1, 1, 1, 0];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#f0f2f9" />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good morning, Alex 👋</Text>
            <Text style={styles.subGreeting}>Build habits. Become your best self.</Text>
          </View>
          <LinearGradient colors={['#667eea', '#764ba2']} style={styles.avatarRing}>
            <View style={styles.avatarInner}>
              <Text style={styles.avatarText}>A</Text>
            </View>
          </LinearGradient>
        </View>

        <View style={styles.streakCard}>
          <View style={styles.streakItem}>
            <LinearGradient colors={['#fff3e0', '#ffe0b2']} style={styles.sIconWrap}><Text style={styles.sIcon}>🔥</Text></LinearGradient>
            <View>
              <Text style={styles.sNum}>12</Text>
              <Text style={styles.sLabel}>Current streak</Text>
            </View>
          </View>
          <View style={styles.sDivider} />
          <View style={styles.streakItem}>
            <LinearGradient colors={['#f3e5f5', '#e1bee7']} style={styles.sIconWrap}><Text style={styles.sIcon}>🏆</Text></LinearGradient>
            <View>
              <Text style={[styles.sNum, { color: '#7c3aed' }]}>27</Text>
              <Text style={styles.sLabel}>Longest streak</Text>
            </View>
          </View>
          <View style={styles.streakRight}>
            <View style={styles.daysRow}>{week.map((d, i) => <Text key={i} style={styles.dayLbl}>{d}</Text>)}</View>
            <View style={styles.dotsRow}>{done.map((v, i) => <View key={i} style={[styles.dot, !v && styles.dotOff]} />)}</View>
            <Text style={styles.keep}>Keep it going! 🔥</Text>
          </View>
        </View>

        <View style={styles.secHdr}>
          <Text style={styles.secTitle}>Your habits</Text>
          <TouchableOpacity style={styles.addBtn}><Text style={styles.addBtnText}>＋ Add habit</Text></TouchableOpacity>
        </View>

        <Shelf items={jarsTop} />
        <Shelf items={jarsBottom} two />

        <TouchableOpacity style={styles.banner} activeOpacity={0.9}>
          <View style={styles.banIcon}><Text style={{ fontSize: 18 }}>✨</Text></View>
          <Text style={styles.banText}>{'Small habits today,\nextraordinary life tomorrow.'}</Text>
          <View style={styles.chev}><Text style={styles.chevText}>›</Text></View>
        </TouchableOpacity>

        <View style={styles.secHdr}>
          <Text style={styles.secTitle}>Today's progress</Text>
          <Text style={styles.viewAll}>View all</Text>
        </View>

        <View style={styles.progressCard}>
          <View style={styles.pi}>
            <LinearGradient colors={['#3b7ef8', '#6366f1']} style={styles.ringDone}><Text style={styles.check}>✓</Text></LinearGradient>
            <View><Text style={styles.piNum}>4</Text><Text style={styles.piLbl}>Completed</Text></View>
          </View>
          <View style={styles.pDiv} />
          <View style={styles.pi}>
            <View style={styles.ringProgress}><View style={styles.ringInner} /></View>
            <View><Text style={styles.piNum}>1</Text><Text style={styles.piLbl}>In progress</Text></View>
          </View>
          <View style={styles.pDiv} />
          <View style={styles.pi}>
            <View style={styles.ringRemain}><View style={styles.ringInner} /></View>
            <View><Text style={styles.piNum}>2</Text><Text style={styles.piLbl}>Remaining</Text></View>
          </View>
        </View>
      </ScrollView>

      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.ni}><Text style={styles.niIconActive}>⌂</Text><Text style={[styles.niLbl, { color: '#3b7ef8' }]}>Home</Text></TouchableOpacity>
        <TouchableOpacity style={styles.ni}><Text style={styles.niIcon}>📊</Text><Text style={styles.niLbl}>Stats</Text></TouchableOpacity>
        <TouchableOpacity style={styles.ni}><Text style={styles.niIcon}>💡</Text><Text style={styles.niLbl}>Insights</Text></TouchableOpacity>
        <TouchableOpacity style={styles.ni}><Text style={styles.niIcon}>⚙️</Text><Text style={styles.niLbl}>Settings</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f0f2f9' },
  scroll: { flex: 1 },
  content: { padding: 18, paddingBottom: 24 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingVertical: 12 },
  greeting: { fontSize: 24, fontWeight: '900', color: '#18192e', letterSpacing: -0.5, lineHeight: 29 },
  subGreeting: { fontSize: 13, color: '#9497b5', marginTop: 4, fontWeight: '500' },
  avatarRing: {
    width: 50, height: 50, borderRadius: 25, padding: 2.5,
    shadowColor: '#667eea', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 10, elevation: 6,
  },
  avatarInner: { flex: 1, borderRadius: 23, backgroundColor: '#7c8ef8', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
  avatarText: { color: '#fff', fontSize: 18, fontWeight: '800' },

  streakCard: {
    backgroundColor: '#fff', borderRadius: 22, padding: 16, marginBottom: 20,
    flexDirection: 'row', alignItems: 'center', gap: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.07, shadowRadius: 14, elevation: 4,
  },
  streakItem: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  sIconWrap: { width: 38, height: 38, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  sIcon: { fontSize: 18 },
  sNum: { fontSize: 24, fontWeight: '900', color: '#18192e', lineHeight: 26 },
  sLabel: { fontSize: 10, color: '#adb0c5', fontWeight: '500' },
  sDivider: { width: 1, height: 42, backgroundColor: '#eef0f8' },
  streakRight: { flex: 1, alignItems: 'flex-end', gap: 5 },
  daysRow: { flexDirection: 'row', gap: 4 },
  dayLbl: { width: 20, textAlign: 'center', fontSize: 9, color: '#b0b3cc', fontWeight: '600' },
  dotsRow: { flexDirection: 'row', gap: 4 },
  dot: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#3b82f6' },
  dotOff: { backgroundColor: '#eef0f8', borderWidth: 1.5, borderColor: '#e0e3f0' },
  keep: { fontSize: 11, fontWeight: '700', color: '#3b7ef8' },

  secHdr: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  secTitle: { fontSize: 20, fontWeight: '900', color: '#18192e', letterSpacing: -0.4 },
  addBtn: {
    backgroundColor: '#fff', borderRadius: 999, paddingHorizontal: 16, paddingVertical: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.08, shadowRadius: 10, elevation: 3,
  },
  addBtnText: { fontSize: 13, fontWeight: '700', color: '#3b7ef8' },

  shelfUnit: {
    borderRadius: 26, backgroundColor: '#f6f7fc', borderWidth: 1, borderColor: 'rgba(255,255,255,0.85)',
    paddingTop: 20, marginBottom: 20, overflow: 'hidden',
    shadowColor: '#000', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.08, shadowRadius: 20, elevation: 6,
  },
  jarsRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'flex-end', gap: 6, paddingHorizontal: 6 },
  jarsRow2: { alignSelf: 'center', gap: 16 },
  jarWrap: { alignItems: 'center' },
  jarName: { fontSize: 11.5, fontWeight: '800', color: '#18192e', textAlign: 'center', marginTop: 4 },
  jarGoal: { fontSize: 9, color: '#adb0c5', textAlign: 'center', fontWeight: '500', marginBottom: 6 },
  shelfBoard: { height: 18, marginTop: 4 },
  shelfFrontEdge: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 5, backgroundColor: '#8a6030' },

  banner: {
    backgroundColor: '#eef1ff', borderRadius: 20, padding: 14, marginVertical: 6, marginBottom: 20,
    flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: 'rgba(99,102,241,0.12)',
  },
  banIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  banText: { flex: 1, fontSize: 13, fontWeight: '800', color: '#18192e', lineHeight: 19 },
  chev: { width: 30, height: 30, borderRadius: 15, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  chevText: { fontSize: 20, color: '#9ea1b2' },

  progressCard: {
    backgroundColor: '#fff', borderRadius: 22, padding: 18, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.07, shadowRadius: 14, elevation: 4,
  },
  pi: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  piNum: { fontSize: 22, fontWeight: '900', color: '#18192e' },
  piLbl: { fontSize: 9.5, color: '#adb0c5', fontWeight: '500' },
  pDiv: { width: 1, height: 38, backgroundColor: '#eef0f8' },
  ringDone: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  check: { color: '#fff', fontSize: 18, fontWeight: '700' },
  ringProgress: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#f97316', alignItems: 'center', justifyContent: 'center' },
  ringRemain: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#eef0f8', borderWidth: 2.5, borderColor: '#e0e3f0', alignItems: 'center', justifyContent: 'center' },
  ringInner: { width: 27, height: 27, borderRadius: 13.5, backgroundColor: '#fff' },
  viewAll: { fontSize: 13, fontWeight: '700', color: '#3b7ef8' },

  bottomNav: {
    flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.97)', borderTopWidth: 1, borderTopColor: 'rgba(0,0,0,0.05)',
    paddingTop: 10, paddingBottom: Platform.OS === 'ios' ? 24 : 12,
  },
  ni: { flex: 1, alignItems: 'center', gap: 3 },
  niIconActive: { fontSize: 22, color: '#3b7ef8' },
  niIcon: { fontSize: 19 },
  niLbl: { fontSize: 10, fontWeight: '600', color: '#b0b3cc' },
});
